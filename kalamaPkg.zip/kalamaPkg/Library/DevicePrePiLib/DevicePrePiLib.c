#include <Library/DevicePrePiLib.h>

VOID
DeviceInitialize () {}
